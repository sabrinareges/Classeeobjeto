public class Main {
    public static void main(String[] args) {

        ContaCorrente corrente =
                new ContaCorrente("Maria", 1000.00, 5.00);

        ContaPoupanca poupanca =
                new ContaPoupanca("João", 1500.00, 0.01);

        System.out.println("=== CONTA CORRENTE ===");

        corrente.exibirSaldo();
        corrente.depositar(500.00);
        corrente.sacar(200.00);
        corrente.exibirSaldo();

        System.out.println("\n=== CONTA POUPANÇA ===");

        poupanca.exibirSaldo();
        poupanca.depositar(300.00);
        poupanca.sacar(200.00);
        poupanca.aplicarRendimento();
        poupanca.exibirSaldo();
    }
}