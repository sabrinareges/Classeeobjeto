
public class Main {
    public static void main(String[] args) {

        Onibus onibus1 = new Onibus("Mercedes-Benz", 45, 4.50);
        Onibus onibus2 = new Onibus("Volkswagen", 50, 5.00);

        Bicicleta bicicleta1 = new Bicicleta("Caloi", 1, "Mountain Bike");
        Bicicleta bicicleta2 = new Bicicleta("Monark", 1, "Urbana");

        System.out.println("=== ÔNIBUS 1 ===");
        onibus1.exibirInformacoes();
        onibus1.mover();

        System.out.println("\n=== ÔNIBUS 2 ===");
        onibus2.exibirInformacoes();
        onibus2.mover();

        System.out.println("\n=== BICICLETA 1 ===");
        bicicleta1.exibirInformacoes();
        bicicleta1.mover();

        System.out.println("\n=== BICICLETA 2 ===");
        bicicleta2.exibirInformacoes();
        bicicleta2.mover();
    }
}
