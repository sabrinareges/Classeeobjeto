public class Main {
    public static void main(String[] args) {

        PagamentoPix pix =
                new PagamentoPix(250.00, "sabrina@email.com");

        PagamentoCartao cartao =
                new PagamentoCartao(600.00, 3);

        pix.exibirComprovante();

        System.out.println();

        cartao.exibirComprovante();
    }
}