public class Main {
    public static void main(String[] args) {

        ProdutoEletronico eletronico1 =
                new ProdutoEletronico("Notebook", 2500.00, 12);

        ProdutoEletronico eletronico2 =
                new ProdutoEletronico("Celular", 1800.00, 24);

        ProdutoAlimenticio alimento1 =
                new ProdutoAlimenticio("Arroz", 30.00, "20/12/2026");

        ProdutoAlimenticio alimento2 =
                new ProdutoAlimenticio("Leite", 6.00, "10/12/2026");

        System.out.println("=== PRODUTOS ELETRÔNICOS ===");
        eletronico1.exibirInformacoes();
        eletronico2.exibirInformacoes();

        System.out.println("\n=== PRODUTOS ALIMENTÍCIOS ===");
        alimento1.exibirInformacoes();
        alimento2.exibirInformacoes();
    }
}