public class Computador extends Dispositivo {
    private String sistemaOperacional;

    public Computador(String marca, String sistemaOperacional) {
        super(marca);
        this.sistemaOperacional = sistemaOperacional;
    }

    @Override
    public void ligar() {
        setLigado(true);
        System.out.println(
                "Computador iniciando o sistema operacional");
    }

    @Override
    public void exibirEstado() {
        System.out.println("=== COMPUTADOR ===");
        super.exibirEstado();
        System.out.println(
                "Sistema operacional: " + sistemaOperacional);
    }
}