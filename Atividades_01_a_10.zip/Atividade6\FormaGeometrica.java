public abstract class FormaGeometrica {

    public abstract double calcularArea();

    public void exibirResultado() {
        System.out.printf("Área: %.2f%n", calcularArea());
    }
}