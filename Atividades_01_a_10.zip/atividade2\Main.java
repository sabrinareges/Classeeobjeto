
public class Main {
    public static void main (String[] args) {

        Cachorro cachorro = new Cachorro("Rex", 3, "Labrador");
        Gato gato = new Gato("Mimi", 2, "Branco");

        System.out.println("=== CACHORRO ===");
        System.out.println("Nome: " + cachorro.getNome());
        System.out.println("Idade: " + cachorro.getIdade());
        System.out.println("Raça: " + cachorro.getRaca());
        cachorro.emitirSom();

        System.out.println();

        System.out.println("=== GATO ===");
        System.out.println("Nome: " + gato.getNome());
        System.out.println("Idade: " + gato.getIdade());
        System.out.println("Cor: " + gato.getCor());
        gato.emitirSom();
    }
}
