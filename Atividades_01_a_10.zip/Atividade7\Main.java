public class Main {
    public static void main(String[] args) {

        Livro livro1 = new Livro(
                "Dom Casmurro", 1899, "Machado de Assis");

        Livro livro2 = new Livro(
                "O Pequeno Príncipe", 1943, "Antoine de Saint-Exupéry");

        Revista revista1 = new Revista(
                "National Geographic", 2024, 150);

        Revista revista2 = new Revista(
                "Superinteressante", 2023, 320);

        livro1.exibirInformacoes();
        livro2.exibirInformacoes();

        revista1.exibirInformacoes();
        revista2.exibirInformacoes();
    }
}