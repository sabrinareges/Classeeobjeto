
public class Main {

    public static void main(String[] args) {

        Funcionario funcionario = new Funcionario("Carlos", 2000.00);

        Gerente gerente = new Gerente("Mariana", 4000.00, 1500.00);

        Vendedor vendedor = new Vendedor("Pedro", 1800.00, 500.00);

        System.out.println("=== FUNCIONARIO ===");
        funcionario.exibirDados();

        System.out.println("\n=== GERENTE ===");
        gerente.exibirDados();

        System.out.println("\n=== VENDEDOR ===");
        vendedor.exibirDados();
    }
}
