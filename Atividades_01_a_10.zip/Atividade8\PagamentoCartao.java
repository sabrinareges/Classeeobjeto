public class PagamentoCartao extends Pagamento {
    private int numeroParcelas;

    public PagamentoCartao(double valor, int numeroParcelas) {
        super(valor);
        this.numeroParcelas = numeroParcelas;
    }

    @Override
    public void processarPagamento() {
        System.out.println("Pagamento via cartão realizado");
    }

    @Override
    public void exibirComprovante() {
        System.out.println("=== COMPROVANTE CARTÃO ===");
        processarPagamento();
        super.exibirComprovante();
        System.out.println("Parcelas: " + numeroParcelas);
        System.out.printf("Valor por parcela: R$ %.2f%n",
                getValor() / numeroParcelas);
    }
}