public class ContaPoupanca extends ContaBancaria {
    private double taxaRendimento;

    public ContaPoupanca(String titular, double saldoInicial, double taxaRendimento) {
        super(titular, saldoInicial);
        this.taxaRendimento = taxaRendimento;
    }

    @Override
    public void sacar(double valor) {
        if (valor > 0 && valor <= getSaldo()) {
            alterarSaldo(getSaldo() - valor);
            System.out.println("Saque realizado sem cobrança de taxa!");
        } else {
            System.out.println("Saque inválido ou saldo insuficiente!");
        }
    }

    public void aplicarRendimento() {
        double rendimento = getSaldo() * taxaRendimento;
        alterarSaldo(getSaldo() + rendimento);
        System.out.println("Rendimento aplicado com sucesso!");
    }
}