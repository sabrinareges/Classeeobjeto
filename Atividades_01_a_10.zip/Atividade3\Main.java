
public class Main {

    public static void main(String[] args) {

        Carro carro = new Carro("Toyota", "Corolla", 2022, 4);

        Moto moto = new Moto("Honda", "CG 160", 2024, 160);

        System.out.println("=== INFORMAÇÕES DO CARRO ===");
        carro.exibirInformacoes();
        carro.ligar();

        System.out.println();

        System.out.println("=== INFORMAÇÕES DA MOTO ===");
        moto.exibirInformacoes();
        moto.ligar();
    }
}
