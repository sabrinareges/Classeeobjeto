public class ContaCorrente extends ContaBancaria {
    private double taxaSaque;

    public ContaCorrente(String titular, double saldoInicial, double taxaSaque) {
        super(titular, saldoInicial);
        this.taxaSaque = taxaSaque;
    }

    @Override
    public void sacar(double valor) {
        double total = valor + taxaSaque;

        if (valor > 0 && total <= getSaldo()) {
            alterarSaldo(getSaldo() - total);
            System.out.println("Saque realizado com taxa!");
        } else {
            System.out.println("Saque inválido ou saldo insuficiente!");
        }
    }
}