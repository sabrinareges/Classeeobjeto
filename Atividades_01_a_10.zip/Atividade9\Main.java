public class Main {
    public static void main(String[] args) {

        Televisao televisao =
                new Televisao("Samsung", 5);

        Computador computador =
                new Computador("ASUS", "Windows 11");

        System.out.println("=== TESTE DA TELEVISÃO ===");

        televisao.ligar();
        televisao.exibirEstado();

        televisao.desligar();
        televisao.exibirEstado();

        System.out.println();

        System.out.println("=== TESTE DO COMPUTADOR ===");

        computador.ligar();
        computador.exibirEstado();

        computador.desligar();
        computador.exibirEstado();
    }
}