public class Produto {
    protected String nome;
    protected double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public double calcularDesconto() {
        return 0;
    }

    public double calcularPrecoFinal() {
        return preco - calcularDesconto();
    }

    public void exibirInformacoes() {
        System.out.println("Produto: " + nome);
        System.out.println("Preço original: R$ " + preco);
        System.out.println("Desconto: R$ " + calcularDesconto());
        System.out.println("Preço final: R$ " + calcularPrecoFinal());
    }
}