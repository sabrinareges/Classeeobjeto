public class Circulo extends FormaGeometrica {

    private double raio;

    public Circulo(double raio) {
        this.raio = raio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * raio * raio;
    }

    @Override
    public void exibirResultado() {
        System.out.println("=== CÍRCULO ===");
        System.out.println("Raio: " + raio);
        super.exibirResultado();
    }
}