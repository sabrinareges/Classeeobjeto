public class Retangulo extends FormaGeometrica {

    private double base;
    private double altura;

    public Retangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public void exibirResultado() {
        System.out.println("=== RETÂNGULO ===");
        System.out.println("Base: " + base);
        System.out.println("Altura: " + altura);
        super.exibirResultado();
    }
}
