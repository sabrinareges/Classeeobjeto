
# Atividade 15 – Estilo Cebraspe (2021)

**Questão:**

Sobre a UML, assinale a alternativa correta.

**Resposta: Alternativa D.**

A UML é uma linguagem visual padronizada utilizada para especificar, visualizar e documentar sistemas, facilitando a representação e compreensão de projetos de software.
