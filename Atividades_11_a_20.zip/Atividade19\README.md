
# Atividade 19 – Estilo Instituto Quadrix (2023)

**Questão:**

A UML possui diferentes tipos de diagramas utilizados para representar aspectos estruturais e comportamentais dos sistemas.

**Resposta: Alternativa E.**

O diagrama de casos de uso representa as funcionalidades e os atores do sistema. O diagrama de classes representa as classes e seus relacionamentos. Já o diagrama de sequência representa as interações entre os objetos ao longo do tempo.
