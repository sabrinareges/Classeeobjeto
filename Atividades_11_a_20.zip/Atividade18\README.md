
# Atividade 18 – Estilo VUNESP (2024)

**Questão:**

Em um sistema de biblioteca, um usuário pode realizar vários empréstimos, enquanto cada empréstimo pertence a um único usuário.

**Resposta: Alternativa A – 1 para 0..*.**

A multiplicidade 1 para 0..* indica que cada empréstimo pertence a um único usuário, enquanto um usuário pode realizar nenhum, um ou vários empréstimos.
