
# Atividade 14 – Estilo Instituto AOCP (2024)

**Questão:**

Em um sistema orientado a objetos, as classes Cachorro e Gato apresentam implementações diferentes do método emitirSom().

**Resposta: Alternativa A – Polimorfismo.**

O polimorfismo permite que diferentes classes implementem o mesmo método de maneiras diferentes, apresentando comportamentos específicos conforme o objeto.
