
# Atividade 16 – Estilo FCC (2022)

**Questão:**

Em um diagrama de classes UML, os símbolos +, - e # representam, respectivamente:

**Resposta: Alternativa B – Público, privado e protegido.**

Na UML, o símbolo + representa a visibilidade pública, o símbolo - representa a visibilidade privada e o símbolo # representa a visibilidade protegida.
