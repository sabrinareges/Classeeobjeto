
# Atividade 17 – Estilo FGV (2023)

**Questão:**

Considere a representação de uma classe UML chamada Aluno.

**Resposta: Alternativa C.**

Os atributos nome e matricula são privados, pois possuem o símbolo (-). Os métodos getNome() e estudar() são públicos, pois possuem o símbolo (+).

