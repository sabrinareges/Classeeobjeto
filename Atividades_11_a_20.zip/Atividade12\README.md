
# Atividade 12 – Estilo FGV (2023)

**Resposta: Alternativa C – Encapsulamento.**

O encapsulamento consiste em proteger os atributos de uma classe, permitindo que sejam acessados ou modificados somente por meio de métodos específicos, como depositar() e sacar().
