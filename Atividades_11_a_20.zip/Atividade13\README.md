# Atividade 13 – Estilo VUNESP (2022)

**Questão:**

Em um sistema de gerenciamento escolar, as classes Professor e Aluno compartilham atributos como nome e CPF, definidos em uma classe Pessoa.

**Resposta: Alternativa E – Herança.**

A herança permite que as classes Professor e Aluno herdem atributos e características da classe Pessoa, evitando a repetição de informações.