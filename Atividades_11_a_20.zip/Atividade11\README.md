
# Atividade 11 – Estilo FCC (2020)

**Questão:**

Na programação orientada a objetos, uma classe pode ser compreendida como:

**Resposta:** Alternativa B.

Uma classe é um modelo que define os atributos (características) e os comportamentos (métodos) que os objetos poderão possuir.
