
# Atividade 20 – Herança e sobrescrita de métodos

**Questão:**

Com base nos conceitos de Programação Orientada a Objetos e no funcionamento do código apresentado, assinale a alternativa correta.

**Resposta: Alternativa B.**

A classe Cachorro herda da classe Animal utilizando a palavra-chave extends e sobrescreve o método emitirSom() com a anotação @Override. Dessa forma, quando o método é chamado pelo objeto Cachorro, a mensagem "Au au!" é exibida no terminal.
